# Točan popis datoteka

## Zamijeni postojeće

- `app/globals.css`
- `app/page.tsx`
- `components/controls.tsx`
- `components/food-entry.tsx`
- `package.json`

## Dodaj nove

- `DESKTOP_DORADE_2026-10-15.md`
- `tests/desktop-browser.mjs`

