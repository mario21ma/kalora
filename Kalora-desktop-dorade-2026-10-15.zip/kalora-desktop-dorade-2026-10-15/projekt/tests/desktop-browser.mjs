import nodeTest, {before, after} from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {initialState, makeItem, baseFoods, dateKey, stateSchema, quantityUnit} from '../lib/domain.ts';
import {baseURL, createHarness, seed, waitDiary, localRecord, savedRecord, switchAccount, activeAccount} from './support/browser-harness.mjs';

// Fresh synthetic accounts and mocked cloud only; the harness rejects external requests.
const {chromium} = createRequire(import.meta.url)(process.env.PLAYWRIGHT_MODULE || 'playwright');
let browser;
const test = (name, run) => nodeTest(name, {timeout: 35_000}, run);
before(async () => {
  assert((await fetch(baseURL)).ok, 'Start the local production server before browser tests');
  browser = await chromium.launch({headless: true, args: ['--no-sandbox'],
    ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE ? {executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE} : {})});
});
after(async () => {await browser?.close()});
function record(layout = 'classic', name = 'Desktop test') {
  const state = initialState(false);
  state.profile = {...state.profile, name, layout}; state.onboarded = true;
  state.items = [makeItem(baseFoods.find(food => food.id === 'banana'), 120, 'breakfast', dateKey(), false)];
  state.waterEntries = [{id: 'desktop-existing-water', date: dateKey(), amountMl: 350, loggedAt: '2026-10-15T08:00:00.000Z'}];
  return {state: stateSchema.parse(state), revision: 1};
}
async function withHarness(records, run) {
  const harness = await createHarness(browser, records);
  try {await run(harness); harness.assertClean()}
  finally {await harness.context.close()}
}
const fits = page => page.evaluate(() => document.documentElement.scrollWidth <= innerWidth);
const waterInput = page => page.getByLabel('Količina vode (ml)', {exact: true});

for (const layout of ['classic', 'compact']) {
  test(`${layout}: desktop columns, food rows and profile fit laptop and wide screens`, async () => {
    const id = 'desktop-width-' + layout, original = record(layout);
    original.state.items[0].name = 'Banana s vrlo dugim nazivom namirnice za provjeru prijeloma retka na računalu';
    await withHarness({[id]: original}, async ({page}) => {
      await page.setViewportSize({width: 1440, height: 1000}); await seed(page, id, original); await page.locator('.energy-card').waitFor();
      await page.getByRole('button', {name: /^Doručak/}).click();
      for (const width of [1024, 1100, 1280, 1440, 1920]) {
        await page.setViewportSize({width, height: 1000});
        assert.equal(await fits(page), true, `${width}: no horizontal document overflow`);
        assert.equal(await waterInput(page).count(), 1);
        assert.equal(await page.locator('.body-silhouette').count(), 2);
        assert.equal(await page.locator('.desktop-food-columns').isVisible(), true);
        const [energy, meals, side] = await Promise.all(['.energy-card', '.meals-section', '.dashboard-grid>.right-stack'].map(selector => page.locator(selector).boundingBox()));
        assert(Math.abs(energy.x - meals.x) < 2);
        assert(meals.y >= energy.y + energy.height);
        if (width >= 1100) {
          await page.locator('.desktop-water-card').waitFor();
          assert(side.x >= energy.x + energy.width);
          assert(Math.abs(side.y - energy.y) < 2);
        } else {
          assert.equal(await page.locator('.desktop-water-card').count(), 0);
        }
        const row = page.locator('.food-row').first();
        assert.equal(await row.evaluate(element => element.scrollWidth <= element.clientWidth + 1), true);
      }
      assert.equal(await page.locator('.side-tabs').getByRole('tab').count(), 5);
      await page.locator('.side-tabs').getByRole('tab', {name: 'Profil', exact: true}).click();
      await page.getByLabel('Kako se zoveš?', {exact: true}).waitFor();
      assert.equal(await fits(page), true);
      assert.deepEqual((await localRecord(page, id)).state, original.state, 'Resizing and navigating do not modify the diary');
    });
  });

  test(`${layout}: moving water controls across breakpoints preserves the draft and adds once`, async () => {
    const id = 'desktop-water-' + layout, original = record(layout);
    await withHarness({[id]: original}, async ({page, cloud}) => {
      await seed(page, id, original); await page.locator('.energy-card').waitFor(); await waterInput(page).fill('375');
      for (const width of [1440, 390, 1100, 1099, 1440]) {
        await page.setViewportSize({width, height: 1000});
        await page.waitForFunction(expected => !!document.querySelector('.desktop-water-card') === expected, width >= 1100);
        assert.equal(await waterInput(page).count(), 1);
        assert.equal(await waterInput(page).inputValue(), '375');
        assert.deepEqual((await localRecord(page, id)).state, original.state);
      }
      await page.getByRole('button', {name: 'Dodaj vodu', exact: true}).click(); await savedRecord(page, id);
      const state = (await localRecord(page, id)).state;
      assert.deepEqual(state.waterEntries.map(entry => entry.amountMl), [350, 375]);
      assert.deepEqual(state.items, original.state.items);
      assert.deepEqual(cloud[id].state.waterEntries, state.waterEntries);
    });
  });
}

test('desktop food entry separates input/review and saves g/ml only after valid confirmation', async () => {
  const id = 'desktop-food-entry', original = record('compact');
  await withHarness({[id]: original}, async ({page, cloud}) => {
    await page.setViewportSize({width: 1440, height: 1000}); await seed(page, id, original); await page.locator('.energy-card').waitFor();
    await page.getByRole('button', {name: 'Dodaj hranu', exact: true}).click();
    const modal = page.getByRole('dialog');
    assert.equal(await page.locator('.desktop-review-empty').isVisible(), true);
    const [left, right] = await Promise.all(['.food-entry-input', '.food-entry-review'].map(selector => page.locator(selector).boundingBox()));
    assert(right.x >= left.x + left.width, 'The review is beside the entry controls');
    await page.getByRole('button', {name: 'Spremljeno', exact: true}).click();
    const search = page.getByRole('textbox', {name: 'Pretraži spremljene namirnice', exact: true});
    for (const [name, label, amount] of [['Mlijeko 2,8%', 'Mililitri za Mlijeko 2,8%', '125'], ['Banana', 'Grami za Banana', '0']]) {
      await search.fill(name); await page.locator('.entry-food-pick').getByText(name, {exact: true}).click();
      await page.getByRole('textbox', {name: label, exact: true}).fill(amount);
    }
    const save = page.getByRole('button', {name: 'Dodaj u dnevnik', exact: true});
    assert.equal(await save.isEnabled(), false);
    assert.deepEqual((await localRecord(page, id)).state, original.state);
    for (const width of [1280, 1100, 1024, 760, 390, 1440]) {
      await page.setViewportSize({width, height: 900});
      assert.equal(await modal.evaluate(element => element.scrollWidth <= element.clientWidth + 1), true, `${width}: the meal dialog fits`);
      assert.equal(await page.getByRole('textbox', {name: 'Mililitri za Mlijeko 2,8%', exact: true}).inputValue(), '125');
      assert.equal(await page.getByRole('textbox', {name: 'Grami za Banana', exact: true}).inputValue(), '0');
      assert.equal(await save.isEnabled(), false);
    }
    await page.getByRole('textbox', {name: 'Grami za Banana', exact: true}).fill('1,25');
    assert.equal(await save.isEnabled(), true);
    assert.equal(await modal.evaluate(element => element.scrollWidth <= element.clientWidth + 1), true);
    await save.click(); await savedRecord(page, id);
    const added = (await localRecord(page, id)).state.items.filter(item => item.id !== original.state.items[0].id);
    assert.deepEqual(added.map(item => [item.foodId, item.grams, quantityUnit(item)]), [['milk', 125, 'ml'], ['banana', 1.25, 'g']]);
    assert.deepEqual(cloud[id].state.items, (await localRecord(page, id)).state.items);
  });
});

test('desktop keyboard edit can be cancelled without saving and returns focus to the food row', async () => {
  const id = 'desktop-keyboard', original = record();
  await withHarness({[id]: original}, async ({page}) => {
    await page.setViewportSize({width: 1440, height: 1000}); await seed(page, id, original); await page.locator('.energy-card').waitFor();
    await page.getByRole('button', {name: /^Doručak/}).click();
    const edit = page.getByRole('button', {name: 'Uredi Banana', exact: true});
    await edit.focus(); await page.keyboard.press('Enter');
    await page.getByLabel('Količina (g)', {exact: true}).fill('0,5');
    await page.keyboard.press('Escape'); await page.getByRole('dialog').waitFor({state: 'hidden'});
    await page.waitForFunction(() => document.activeElement?.getAttribute('aria-label') === 'Uredi Banana');
    assert.deepEqual((await localRecord(page, id)).state, original.state);
    await page.locator('.sidebar-add').click();
    await page.getByRole('button', {name: 'Spremljeno', exact: true}).click();
    await page.getByRole('button', {name: 'Točna deklaracija', exact: true}).click();
    await page.getByRole('heading', {name: 'Tvoja namirnica', exact: true}).waitFor();
    await page.getByRole('textbox', {name: 'Naziv proizvoda', exact: true}).fill('Nespremljeni proizvod');
    // Let the old dialog finish closing; it must not steal the new dialog's focus.
    await page.waitForTimeout(400);
    assert.equal(await page.getByRole('textbox', {name: 'Naziv proizvoda', exact: true}).evaluate(element => element === document.activeElement), true);
    await page.keyboard.press('Escape');
    assert.deepEqual((await localRecord(page, id)).state, original.state);
  });
});

test('mobile keeps one-column entry, silhouettes, macro colors and the existing water control', async () => {
  for (const layout of ['classic', 'compact']) {
    const id = 'desktop-mobile-' + layout, original = record(layout);
    await withHarness({[id]: original}, async ({page}) => {
      await seed(page, id, original); await page.locator('.energy-card').waitFor();
      await page.getByRole('button', {name: /^Doručak/}).click();
      for (const width of [320, 390, 760]) {
        await page.setViewportSize({width, height: 1000});
        assert.equal(await fits(page), true);
        assert.equal(await page.locator('.desktop-food-columns').isVisible(), false);
        assert.equal(await page.locator('.desktop-row-edit-icon').isVisible(), false);
        assert.equal(await page.locator('.desktop-water-card').count(), 0);
        assert.equal(await waterInput(page).count(), 1);
        assert.equal(await page.locator('.body-silhouette').count(), 2);
      }
      const colors = await page.locator('.energy-card .macro-progress [data-slot="progress-indicator"]').evaluateAll(elements => elements.map(element => getComputedStyle(element).backgroundColor));
      assert.equal(colors.length, 3); assert.equal(new Set(colors).size, 3);
      await page.setViewportSize({width: 390, height: 1000});
      await page.getByRole('button', {name: 'Dodaj hranu', exact: true}).click();
      assert.equal(await page.locator('.desktop-review-empty').isVisible(), false);
      assert.equal(await page.locator('.food-entry-input').evaluate(element => getComputedStyle(element).display), 'contents');
      await page.getByRole('textbox', {name: 'Opis obroka', exact: true}).fill('100 g kruha');
      await page.getByRole('button', {name: 'Analiziraj', exact: true}).click();
      assert.equal(await page.locator('.preview-section').isVisible(), true);
      assert.deepEqual((await localRecord(page, id)).state, original.state);
    });
  }
});

test('a two-tab account change resets the desktop water draft and writes only to the new account', async () => {
  const a = 'desktop-water-alice', b = 'desktop-water-bruno';
  const records = {[a]: record('compact', 'Desktop Alice'), [b]: record('classic', 'Desktop Bruno')};
  await withHarness(records, async ({page, context, cloud, errors}) => {
    await page.setViewportSize({width: 1440, height: 1000}); await seed(page, a, records[a]); await page.locator('.energy-card').waitFor();
    await waterInput(page).fill('875');
    const other = await context.newPage(); other.on('pageerror', error => errors.push(error.message));
    await other.goto(baseURL, {waitUntil: 'networkidle'}); await waitDiary(other);
    await switchAccount(other, b, records[b]); await activeAccount(page, 'Desktop Bruno');
    assert.equal(await waterInput(page).inputValue(), '250');
    await waterInput(page).fill('125'); await page.getByRole('button', {name: 'Dodaj vodu', exact: true}).click(); await savedRecord(page, b);
    assert.deepEqual(cloud[a], records[a]);
    assert.deepEqual((await localRecord(page, a)).state, records[a].state);
    assert.deepEqual(cloud[b].state.waterEntries.map(entry => entry.amountMl), [350, 125]);
  });
});
