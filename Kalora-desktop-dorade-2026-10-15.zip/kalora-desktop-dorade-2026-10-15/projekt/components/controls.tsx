'use client';
import {useEffect,useRef} from 'react';
import {Select,SelectContent,SelectItem,SelectTrigger,SelectValue} from '@/components/ui/select';
import {Dialog,DialogContent,DialogTitle,DialogDescription} from '@/components/ui/dialog';
import {X} from 'lucide-react';
export function Choice({value,onChange,options,label}:{value:string,onChange:(v:string)=>void,options:{value:string,label:string}[],label:string}){return <Select value={value} onValueChange={onChange}><SelectTrigger className="choice" aria-label={label}><SelectValue placeholder="Odaberi…"/></SelectTrigger><SelectContent>{options.map(o=><SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent></Select>}
export function Modal({open,onClose,title,description,children,className=''}:{open:boolean,onClose:()=>void,title:string,description:string,children:React.ReactNode,className?:string}){
 const returnFocus=useRef<HTMLElement|null>(null);
 useEffect(()=>{
  if(open)return;
  // Capture before React autoFocus moves into a dialog. Radix may skip its
  // onOpenAutoFocus callback when an input has already received focus.
  const rememberOpener=(event:Event)=>{
   const element=event.target instanceof Element?event.target.closest<HTMLElement>('button,a,input,textarea,select,[tabindex]'):null;
   if(element&&!element.closest('[role="dialog"]'))returnFocus.current=element;
  };
  document.addEventListener('focusin',rememberOpener,true);
  document.addEventListener('pointerdown',rememberOpener,true);
  return()=>{
   document.removeEventListener('focusin',rememberOpener,true);
   document.removeEventListener('pointerdown',rememberOpener,true);
  };
 },[open]);
 return <Dialog open={open} onOpenChange={v=>!v&&onClose()}><DialogContent
  className={['app-modal',className].filter(Boolean).join(' ')} showCloseButton={false}
  onOpenAutoFocus={()=>{const element=document.activeElement;if(element instanceof HTMLElement&&!element.closest('[role="dialog"]'))returnFocus.current=element}}
  onCloseAutoFocus={event=>{
   // These controlled dialogs have no Radix Trigger. Restore the actual opener,
   // unless another dialog has opened or the account/row has been removed.
   event.preventDefault();
   if(!document.querySelector('[role="dialog"][data-state="open"]')&&returnFocus.current?.isConnected)returnFocus.current.focus({preventScroll:true});
  }}>
  <button className="close icon-button" aria-label="Zatvori" onClick={onClose}><X size={22}/></button><DialogTitle className="modal-title">{title}</DialogTitle><DialogDescription className="muted">{description}</DialogDescription>{children}
 </DialogContent></Dialog>;
}
