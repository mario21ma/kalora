# Kalora — desktop dorade, 15. listopada 2026.

Ovo je nadogradnja verzije main `2e37a54` (UI 6.5), nakon prethodnog novog izgleda i boja makronutrijenata. Nije cijeli projekt. Izvor paketa: `0cb9f4ef14b951d45a6e28df15b2d15d3377a7e8`.

## 1. Kopiranje datoteka

1. Sačuvaj kopiju trenutačnog projekta ili Git commit. Ako si dodatno mijenjao iste datoteke, usporedi ih prije zamjene.
2. Raspakiraj ZIP u zasebnu mapu.
3. Iz mape `projekt/` prenesi datoteke na iste putanje u postojeći projekt, gdje se nalazi `package.json`.
4. Zamijeni 5 postojećih datoteka i dodaj 2 nove. Točan popis je u `POPIS_DATOTEKA.md`.

Spajaj sadržaj mapa; nemoj zamijeniti ili izbrisati cijele mape app, components ili tests. Sačuvaj `.env.local`, ključeve i sve ostale datoteke. Ne briši localStorage, dnevnike, sigurnosne kopije ni instalirani PWA. Kopira se samo sadržaj `projekt/`; pomoćne datoteke na vrhu ZIP-a ne idu u aplikaciju.

## 2. PowerShell provjere

U mapi projekta gdje je package.json, s Node.js 22 i pnpm 11.25.0 pokreni redom:

```powershell
pnpm install --frozen-lockfile
pnpm test
pnpm test:database
pnpm typecheck
pnpm build
```

Ako naredba javi grešku, stani i pregledaj ispis. Nema novih ovisnosti; lockfile se ne mijenja. Upute za lokalni preglednik su u `projekt/DESKTOP_DORADE_2026-10-15.md`.

## 3. Što ćeš vidjeti

Desktop raspored uključuje se automatski. Na širem prozoru voda je desno, a unos hrane i njegova provjera su jedan uz drugi. Mobilni raspored ostaje; Klasični/Kompaktni i dalje se biraju kroz Profil → Izgled aplikacije.

## 4. SQL i produkcija

SQL ne treba pokretati za ovaj paket. Nema nove migracije, ključeva ni varijabli okruženja. Paket nije automatski objavljen u produkciju.

Primijeni prvo na grani za pregled. Spremanje u main povezan s Vercelom može automatski objaviti aplikaciju. Hosted Preview s testovima koji mijenjaju podatke mora koristiti odvojenu testnu Supabase bazu i njezine ključeve.

Nakon buduće objave otvori aplikaciju online i ponovno pokreni postojeći PWA. Korisnički podaci ne brišu se radi nadogradnje.

## Alternativa za Git

Umjesto kopiranja, iz korijena projekta:

```powershell
git apply --check C:/putanja/do/kalora-desktop-dorade.patch
git apply C:/putanja/do/kalora-desktop-dorade.patch
```

Drugu naredbu pokreni samo ako prva prođe. Kopiranje i patch su alternative; ne primjenjuj oba. Ne forsiraj patch preko novijih promjena.

## Dokazi i ograničenja

Prošlo je 217 osnovnih, 7 lokalnih SQL i 53 preglednička testa, TypeScript i produkcijski build. Rezultati, scenariji i preostale ručne provjere su u dokumentu DESKTOP_DORADE_2026-10-15.md. Lokalni testovi koriste sintetičke račune i simulirane cloud odgovore. Stvarna produkcija i fizički telefon nisu provjereni ovim testovima.
