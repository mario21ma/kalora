# Kalora — NOVI IZGLED I UNOS, 15. listopada 2026.

Ovo je novi programski paket, nakon prethodnih beta popravaka. Dodaje Klasični/Kompaktni izgled, objedinjene postavke i jasniji unos hrane. Nije cijeli projekt. Napravljen je prema main verziji e006908 (UI 6.3); izvor ovog paketa je 1de13d5eb880c9bcbf32b8566e6cda0e3c15c4eb.

## 1. Zamijeni i dodaj

- Sačuvaj kopiju svojeg trenutačnog projekta ili Git commit. Ako si dodatno mijenjao iste datoteke, prvo ih usporedi.
- Raspakiraj ZIP u zasebnu mapu.
- Iz mape `projekt/` prenesi datoteke na iste putanje u postojeći projekt, u korijen gdje je `package.json`.
- Zamijeni 10 postojećih i dodaj 8 novih datoteka. Popis je u `POPIS_DATOTEKA.md`.
- Spajaj sadržaj mapa. Nemoj zamijeniti ili izbrisati cijele mape `app`, `components`, `lib`, `tests` ili `public`.
- Sačuvaj `.env.local`, ključeve i ostale datoteke. Ne briši localStorage, korisničke dnevnike, sigurnosne kopije ili instalirani PWA.

Pomoćne datoteke na vrhu ZIP-a nisu za kopiranje u aplikaciju; kopira se samo sadržaj `projekt/`.

## 2. PowerShell provjere

Otvori PowerShell u mapi Kalore gdje je `package.json`. Koristi Node.js22 i pnpm11.25.0. Pokreni redom:

    pnpm install --frozen-lockfile
    pnpm test
    pnpm test:database
    pnpm typecheck
    pnpm build

Ako neka naredba javi grešku, stani i pregledaj ispis. Pregledničke testove možeš pokrenuti nakon lokalnog servera i instalacije Playwright Chromiuma; detalji su u `projekt/IZGLED_I_UNOS_2026-10-15.md`.

## 3. Kako uključiti novi izgled

Klasični izgled ostaje zadani. U aplikaciji otvori:

    Profil → Izgled aplikacije → Kompaktni → Spremi izgled

Na istom mjestu možeš promijeniti boju i prikaz silueta/vode, pa potvrditi Spremi izgled. Gašenje prikaza vode čuva unesenu vodu. Osobni podaci i cilj vode spremaju se zasebno gumbom Spremi profil.

Dodaj hranu sada ima Opiši, Barkod i Spremljeno. Namirnice/favoriti ulaze u pregled; spremanje u dnevnik traži potvrdu.

## 4. SQL i objava

SQL NE treba ponovno pokretati za ovaj paket. Nema nove SQL migracije niti novih ključeva/varijabli; postavka rasporeda koristi postojeći profil.

Prvo primijeni na grani za pregled. Spremanje u main povezan s Vercelom može automatski objaviti aplikaciju. Ovaj paket nije automatski primijenjen na produkciju. Ako radiš hosted Preview i testove koji mijenjaju podatke, koristi odvojenu testnu Supabase bazu i njezine ključeve, ne produkcijske.

Nakon buduće objave provjeri aplikaciju online i ponovno je otvori kako bi preuzela novu verziju. Ne briši korisničke podatke radi nadogradnje.

## Alternativa za Git

Umjesto kopiranja, iz korijena projekta:

    git apply --check /putanja/do/kalora-novi-izgled.patch
    git apply /putanja/do/kalora-novi-izgled.patch

Drugu naredbu pokreni samo ako prva prođe. Kopiranje i patch su alternative; ne primjenjuj oba. Ne forsiraj patch preko svojih novijih promjena.

## Dokazi i preostale provjere

Točni lokalni rezultati i preostale ručne provjere na telefonu zapisani su u `projekt/IZGLED_I_UNOS_2026-10-15.md`. Lokalni SQL koristi PGlite, a UI testovi sintetičke račune i simulirane odgovore. Stvarni Supabase, AI model i fizička kamera nisu dio tih lokalnih testova.

Ponavljanje jučerašnjeg obroka ostavljeno je za sljedeću doradu.
