# Točan popis datoteka

## Zamijeni postojeće

- `app/globals.css`
- `app/page.tsx`
- `components/profile.tsx`
- `lib/domain.ts`
- `lib/profile-draft.ts`
- `package.json`
- `public/sw.js`
- `tests/browser-regressions.mjs`
- `tests/database.test.mjs`
- `tests/profile-draft.test.mjs`

## Dodaj nove

- `IZGLED_I_UNOS_2026-10-15.md`
- `components/appearance-settings.tsx`
- `components/food-entry.tsx`
- `lib/appearance.ts`
- `lib/item-provenance.ts`
- `tests/appearance-browser.mjs`
- `tests/appearance.test.mjs`
- `tests/item-provenance.test.mjs`

