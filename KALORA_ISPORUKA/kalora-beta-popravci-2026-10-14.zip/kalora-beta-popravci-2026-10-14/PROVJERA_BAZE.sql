-- Samo citanje: ovi upiti ne mijenjaju podatke ni shemu.
-- U Supabase SQL Editoru mozes najprije izvrsiti samo prvi SELECT.
select
 to_regclass('public.profiles') is not null as profiles,
 to_regclass('public.ai_usage') is not null as ai_usage,
 to_regclass('public.daily_water') is not null as daily_water,
 to_regclass('public.water_entries') is not null as water_entries,
 to_regclass('public.ai_request_usage') is not null as ai_request_usage,
 to_regprocedure('public.load_diary()') is not null as load_diary,
 to_regprocedure('public.save_diary(jsonb,bigint)') is not null as save_diary,
 to_regprocedure('public.consume_ai_request_quota(text,uuid,integer,integer,integer,integer,integer,integer)') is not null as ai_quota_rpc;

-- Nakon migracija: ocekuju se dva retka s tgenabled = 'O'.
select tgname,tgenabled from pg_catalog.pg_trigger
 where not tgisinternal and tgname in ('kalora_delete_ai_quota','kalora_check_ai_quota_account');

-- Nakon migracija: oba RPC-a trebaju individual_water = true.
select proname,pg_catalog.pg_get_functiondef(oid) like '%waterEntries%' as individual_water
 from pg_catalog.pg_proc
 where oid in (to_regprocedure('public.load_diary()'),to_regprocedure('public.save_diary(jsonb,bigint)'));
