# Datoteke za zamjenu i dodavanje

18 postojećih datoteka za zamjenu i 3 nove datoteke. Sve su u mapi `projekt/`.

## Zamijeni postojeće

- `app/page.tsx`
- `app/privacy/page.tsx`
- `components/profile.tsx`
- `lib/barcode-scanner.ts`
- `lib/cloud.ts`
- `lib/diary-storage.ts`
- `lib/diary-store.ts`
- `lib/domain.ts`
- `lib/undo.ts`
- `package.json`
- `public/sw.js`
- `tests/browser-regressions.mjs`
- `tests/diary-store.test.mjs`
- `tests/domain.test.mjs`
- `tests/pwa-deploy.test.mjs`
- `tests/scanner.test.mjs`
- `tests/session.test.mjs`
- `tests/undo.test.mjs`

## Dodaj nove

- `BETA_FINAL_FIXES.md`
- `lib/profile-draft.ts`
- `tests/profile-draft.test.mjs`

