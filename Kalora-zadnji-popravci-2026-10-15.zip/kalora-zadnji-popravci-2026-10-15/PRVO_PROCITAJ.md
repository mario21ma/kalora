# Kalora — zadnji popravci, 15. listopada 2026.

Ovo je NOVI paket s posljednjim popravcima (izvor a83a04e), nakon prethodne isporuke. Predviđen je za projekt na polaznoj verziji 7aead637 (UI 6.2). Nije cijela aplikacija. Ima 18 datoteka za zamjenu i 3 nove.

## Što napraviti

1. Sačuvaj kopiju svojeg trenutačnog projekta ili Git commit. Ako imaš svoje novije promjene u istim datotekama, prvo ih usporedi; nemoj ih slijepo prepisati.
2. Raspakiraj ZIP u zasebnu mapu.
3. Otvori mapu `projekt/` iz ZIP-a. Njezin sadržaj kopiraj u korijen svojeg postojećeg Kalora projekta, gdje je `package.json`. Zadrži izvorne putanje: primjerice `projekt/lib/cloud.ts` ide u `lib/cloud.ts`.
4. Spoji sadržaj mapa, zamijeni samo 18 navedenih datoteka i dodaj 3 nove. Točan popis je u `POPIS_DATOTEKA.md`. Nemoj brisati ili zamijeniti cijele mape `app`, `lib`, `tests` ili `public`.
5. Sačuvaj `.env.local`, postojeće ključeve, ostale projektne datoteke i korisničke podatke. Ne briši localStorage, sigurnosne kopije ili instalirani PWA radi ove nadogradnje.
6. SQL NE treba ponovno pokretati za ovaj paket. Nijedna nova SQL migracija nije dodana.
7. Prvo primijeni na zasebnoj grani za pregled. Spremanje na GitHub granu povezanu s Vercelom može pokrenuti automatsku objavu. Nemoj kopirati izravno u produkcijski `main` prije pregleda i provjere.

Upute, manifest, patch i popis na vrhu ZIP-a pomoćne su datoteke; ne treba ih kopirati u aplikaciju. Datoteka `projekt/BETA_FINAL_FIXES.md` jest izvještaj za projekt i može se dodati prema popisu.

## Ako koristiš Git

Umjesto ručnog kopiranja možeš primijeniti priloženi patch iz korijena svojeg projekta:

    git apply --check /putanja/do/kalora-zadnji-popravci.patch
    git apply /putanja/do/kalora-zadnji-popravci.patch

Drugu naredbu pokreni samo ako prva prođe. Kopiranje i patch su dva alternativna načina; ne primjenjuj oba. Ako provjera ne prođe, usporedi svoje izmjene s polaznom verzijom; nemoj prisilno primjenjivati patch.

## Provjere nakon zamjene

Node.js 22 i pnpm 11.25.0:

    pnpm install --frozen-lockfile
    pnpm test
    pnpm test:database
    pnpm typecheck
    pnpm build

Za pregledničke testove pokreni lokalni produkcijski server pa u drugom terminalu `pnpm test:browser`, uz adresu servera kroz `KALORA_BROWSER_URL` i instaliran Playwright Chromium ili `PLAYWRIGHT_CHROMIUM_EXECUTABLE`. Puni primjeri i granice provjera nalaze se u `projekt/BETA_FINAL_FIXES.md`.

Na ovom izvoru prošlo je 198 osnovnih, 7 SQL i 36 pregledničkih testova, TypeScript i produkcijski build. To su lokalne provjere, ne provjere produkcijskog Supabasea ili fizičkog telefona. Hosted Preview za testove koji mijenjaju podatke mora imati odvojenu testnu Supabase bazu i njezine ključeve, nikako produkcijske.

Na telefonu još provjeriti PWA instalaciju/nadogradnju i offline ponovno otvaranje, kameru/barkod, male decimalne količine i pristupačnost. Na odvojenoj testnoj bazi provjeriti stvarnu prijavu/obnovu, dva uređaja, konflikt i brisanje testnog računa. Kod je kandidat za zatvorenu betu; pozivnice čekaju te stvarne provjere.
